exports.TOKEN = process.env.TOKEN_BOT;

exports.PREFIX = '.';

exports.GOOGLE_API_KEY = process.env.GOOGLE_API;

exports.GENIUS_API_KEY = process.env.GEN_API;

exports.yandex_API = process.env.YANDEX_API;

exports.news_API = '';

exports.giphy_API = process.env.GIF_API;

exports.AME_API = '';

exports.blague_API = '';
